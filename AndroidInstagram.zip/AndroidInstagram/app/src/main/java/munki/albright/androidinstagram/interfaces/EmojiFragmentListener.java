package munki.albright.androidinstagram.interfaces;

public interface EmojiFragmentListener {
    void onEmojiSelected(String emoji);
}
