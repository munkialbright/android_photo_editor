package munki.albright.androidinstagram.interfaces;

public interface FiltersListFragmentListener {
    void onFilterSelected(com.zomato.photofilters.imageprocessors.Filter filter);
}
