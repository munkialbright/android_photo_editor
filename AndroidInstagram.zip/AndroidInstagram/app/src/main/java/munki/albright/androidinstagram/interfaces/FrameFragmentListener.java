package munki.albright.androidinstagram.interfaces;

public interface FrameFragmentListener {
    void onAddFrame(int frame);
}
