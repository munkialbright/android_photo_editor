package munki.albright.androidinstagram.interfaces;

import android.graphics.Typeface;

public interface TextFragmentListener {
    void onTextButtonClick(Typeface typeface, String text, int color);
}
